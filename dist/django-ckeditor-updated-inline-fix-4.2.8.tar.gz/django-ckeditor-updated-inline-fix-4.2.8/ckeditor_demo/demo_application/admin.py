from ckeditor_demo.demo_application import models

from django.contrib import admin


admin.site.register(models.ExampleModel)
