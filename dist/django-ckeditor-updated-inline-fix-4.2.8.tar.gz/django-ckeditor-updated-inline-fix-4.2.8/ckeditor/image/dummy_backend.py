def create_thumbnail(file_path, format):
    raise NotImplementedError


def should_create_thumbnail(file_path):
    return False


def image_verify(f):
    return
